var typingEffect = new Typed('.multiText',{
  strings : ['Siz bu saytdan "essential 400words" kitobining barcha qismlarini va ulardagi sozlarning tarjimasini topishingiz mumkin.','You can find all sections of the book "essential 400words" and the translation of the words in them on this site.'],
  loop:true,
  typeSpeed:30,
  backSpeed:30,
})
var swiper = new Swiper(".mySwiper", {
  effect: "coverflow",
  loop:true,
  grabCursor: true,
  centeredSlides: true,
  slidesPerView: "auto",
  coverflowEffect: {
    rotate: 50,
    stretch: 1,
    depth: 100,
    modifier: 1,
    slideShadows: true,
  },
  autoplay: {
    delay: 2500,
    disableOnInteraction: false,
  },
  pagination: {
    el: ".swiper-pagination",
  },
});